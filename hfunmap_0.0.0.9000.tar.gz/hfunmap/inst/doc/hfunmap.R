## ----eval=FALSE,results=FALSE-------------------------------------------------
#      >install.packages("C:/yourpath/hfunmap0.0.0.9.zip", repos=NULL)

## ----eval=FALSE, results=FALSE------------------------------------------------
#  knitr::opts_chunk$set(eval = FALSE, include = FALSE)
#      >install.packages("C:/yourpath/hfunmap0.0.0.9.tar.gz",repos=NULL)

## ----eval=FALSE, results=FALSE------------------------------------------------
#      $ git clone https://github.com/~/hfunmap.git
#      $ cd hfunmap
#      $ R CMD INSTALL hfunmap'

## ----eval=FALSE,results=FALSE-------------------------------------------------
#  >library(hfunmap)

## ----eval=FALSE,results=FALSE-------------------------------------------------
#      >c(1,3,5,7,9,11,13,16,19,23,28,32,39,47)

## ----eval=FALSE,results=FALSE-------------------------------------------------
#      >int 4

## ----eval=FALSE,results=FALSE-------------------------------------------------
#      >logical TRUE/FALSE

## ----eval=FALSE,results=FALSE-------------------------------------------------
#      >int 3

## ----eval=FALSE, results=FALSE------------------------------------------------
#  # Load the pre-installed data for the example
#  data("test_data")
#  
#  #calculate likelihood ratio value
#  r <- hfun_lr_cal(test_data,interval = c(1:2))
#  
#  #calculate threshold
#  cutlevel <- hfun_permutation(test_data,permu_times = 2,interval = c(1:2),cutp = 0.05)
#  
#  #find the significant QTL site
#  sig_sit1 <- which(r[,1] > cutlevel$cut1)
#  sig_sit2 <- which(r[,1] > cutlevel$cut2)

## ----eval=FALSE,results=FALSE-------------------------------------------------
#  test_data <- hfun_load_data(address.p = "../phe*.csv",
#                 address.g = "./geno*.csv",
#                 Times = c(1,3,5,7,9,11,13,16,19,23,28,32,39,47),
#                 missing = TRUE,
#                 log.p = FALSE,
#                 fit.check = FALSE)

