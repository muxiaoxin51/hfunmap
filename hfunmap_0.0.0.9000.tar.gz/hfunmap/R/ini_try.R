#' Hello
#'
#' @return hello world!
#' @export
hello <- function(){
  cat("hello world!\n")
}
